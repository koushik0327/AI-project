"""
Top-Down 2D Intersection Visualizer for TrafficFlow AI.

Renders an interactive SVG-based visual representation of the 4-way intersection,
including road geometry, stop lines, traffic signals, vehicle queues, and moving cars.
"""

from typing import Dict, List
from environment.intersection import Intersection, SignalPhase
from environment.vehicle import Vehicle


def generate_intersection_svg(
    intersection: Intersection,
    vehicles: List[Vehicle],
    current_time: float,
    width: int = 700,
    height: int = 700,
) -> str:
    """
    Generate an SVG string depicting the intersection and all active vehicles.

    Coordinate system: Center (0, 0) mapped to SVG (width/2, height/2).
    Scale factor: 1 meter ~ 2.2 SVG pixels.

    Args:
        intersection: Current Intersection state.
        vehicles: List of all active vehicles.
        current_time: Simulation timestamp in seconds.
        width: SVG canvas width in pixels.
        height: SVG canvas height in pixels.

    Returns:
        Clean SVG XML string ready for rendering.
    """
    cx = width / 2.0
    cy = height / 2.0
    scale = 2.0  # 1 meter = 2.0 pixels

    # Road dimensions in SVG pixels
    road_half_width = 16.0 * scale  # 32m wide road (2 lanes each way)
    lane_width = road_half_width / 2.0

    # Signal states
    sig_n = intersection.get_signal_state("N")
    sig_s = intersection.get_signal_state("S")
    sig_e = intersection.get_signal_state("E")
    sig_w = intersection.get_signal_state("W")

    def signal_color(state: str) -> str:
        if state == "GREEN":
            return "#2ecc71"
        elif state == "YELLOW":
            return "#f1c40f"
        return "#e74c3c"

    # SVG generation
    svg = []
    svg.append(f'<svg width="100%" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">')
    svg.append('<defs>')
    svg.append('  <pattern id="roadGrid" width="40" height="40" patternUnits="userSpaceOnUse">')
    svg.append('    <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1f2937" stroke-width="0.5"/>')
    svg.append('  </pattern>')
    # Glow filter for active traffic lights
    svg.append('  <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">')
    svg.append('    <feGaussianBlur stdDeviation="3" result="coloredBlur"/>')
    svg.append('    <feMerge>')
    svg.append('      <feMergeNode in="coloredBlur"/>')
    svg.append('      <feMergeNode in="SourceGraphic"/>')
    svg.append('    </feMerge>')
    svg.append('  </filter>')
    svg.append('</defs>')

    # Background terrain (Grass / urban landscape)
    svg.append(f'<rect width="{width}" height="{height}" fill="#0f172a" rx="12"/>')
    svg.append(f'<rect width="{width}" height="{height}" fill="url(#roadGrid)" opacity="0.4"/>')

    # Road background (North-South Road)
    svg.append(
        f'<rect x="{cx - road_half_width}" y="0" width="{road_half_width * 2}" height="{height}" fill="#1e293b"/>'
    )
    # Road background (East-West Road)
    svg.append(
        f'<rect x="0" y="{cy - road_half_width}" width="{width}" height="{road_half_width * 2}" fill="#1e293b"/>'
    )

    # Intersection conflict zone box
    svg.append(
        f'<rect x="{cx - road_half_width}" y="{cy - road_half_width}" width="{road_half_width * 2}" height="{road_half_width * 2}" fill="#243044"/>'
    )

    # Road borders (curbs)
    curb_color = "#475569"
    # NW corner curb
    svg.append(f'<line x1="0" y1="{cy - road_half_width}" x2="{cx - road_half_width}" y2="{cy - road_half_width}" stroke="{curb_color}" stroke-width="3"/>')
    svg.append(f'<line x1="{cx - road_half_width}" y1="0" x2="{cx - road_half_width}" y2="{cy - road_half_width}" stroke="{curb_color}" stroke-width="3"/>')
    # NE corner curb
    svg.append(f'<line x1="{cx + road_half_width}" y1="0" x2="{cx + road_half_width}" y2="{cy - road_half_width}" stroke="{curb_color}" stroke-width="3"/>')
    svg.append(f'<line x1="{cx + road_half_width}" y1="{cy - road_half_width}" x2="{width}" y2="{cy - road_half_width}" stroke="{curb_color}" stroke-width="3"/>')
    # SW corner curb
    svg.append(f'<line x1="0" y1="{cy + road_half_width}" x2="{cx - road_half_width}" y2="{cy + road_half_width}" stroke="{curb_color}" stroke-width="3"/>')
    svg.append(f'<line x1="{cx - road_half_width}" y1="{cy + road_half_width}" x2="{cx - road_half_width}" y2="{height}" stroke="{curb_color}" stroke-width="3"/>')
    # SE corner curb
    svg.append(f'<line x1="{cx + road_half_width}" y1="{cy + road_half_width}" x2="{width}" y2="{cy + road_half_width}" stroke="{curb_color}" stroke-width="3"/>')
    svg.append(f'<line x1="{cx + road_half_width}" y1="{cy + road_half_width}" x2="{cx + road_half_width}" y2="{height}" stroke="{curb_color}" stroke-width="3"/>')

    # Yellow dashed centerlines
    dash_color = "#eab308"
    # North centerline
    svg.append(f'<line x1="{cx}" y1="0" x2="{cx}" y2="{cy - road_half_width}" stroke="{dash_color}" stroke-width="2.5" stroke-dasharray="10,8"/>')
    # South centerline
    svg.append(f'<line x1="{cx}" y1="{cy + road_half_width}" x2="{cx}" y2="{height}" stroke="{dash_color}" stroke-width="2.5" stroke-dasharray="10,8"/>')
    # West centerline
    svg.append(f'<line x1="0" y1="{cy}" x2="{cx - road_half_width}" y2="{cy}" stroke="{dash_color}" stroke-width="2.5" stroke-dasharray="10,8"/>')
    # East centerline
    svg.append(f'<line x1="{cx + road_half_width}" y1="{cy}" x2="{width}" y2="{cy}" stroke="{dash_color}" stroke-width="2.5" stroke-dasharray="10,8"/>')

    # White Stop lines
    stop_color = "#ffffff"
    stop_width = 4
    # North stop line (vehicles coming down, stop at y = cy - road_half_width)
    svg.append(f'<line x1="{cx - road_half_width}" y1="{cy - road_half_width}" x2="{cx}" y2="{cy - road_half_width}" stroke="{stop_color}" stroke-width="{stop_width}"/>')
    # South stop line (vehicles coming up, stop at y = cy + road_half_width)
    svg.append(f'<line x1="{cx}" y1="{cy + road_half_width}" x2="{cx + road_half_width}" y2="{cy + road_half_width}" stroke="{stop_color}" stroke-width="{stop_width}"/>')
    # East stop line (vehicles coming left, stop at x = cx + road_half_width)
    svg.append(f'<line x1="{cx + road_half_width}" y1="{cy - road_half_width}" x2="{cx + road_half_width}" y2="{cy}" stroke="{stop_color}" stroke-width="{stop_width}"/>')
    # West stop line (vehicles coming right, stop at x = cx - road_half_width)
    svg.append(f'<line x1="{cx - road_half_width}" y1="{cy}" x2="{cx - road_half_width}" y2="{cy + road_half_width}" stroke="{stop_color}" stroke-width="{stop_width}"/>')

    # Draw Traffic Signal Poles and Bulbs
    def draw_signal(box_x, box_y, color, label):
        # Housing box
        svg.append(f'<rect x="{box_x - 14}" y="{box_y - 14}" width="28" height="28" rx="6" fill="#090d16" stroke="#475569" stroke-width="1.5"/>')
        # Active light bulb
        svg.append(f'<circle cx="{box_x}" cy="{box_y}" r="8" fill="{color}" filter="url(#glow)"/>')
        # Direction label
        svg.append(f'<text x="{box_x}" y="{box_y + 3}" font-family="monospace" font-size="8" font-weight="bold" fill="#000000" text-anchor="middle">{label}</text>')

    # Place signals near their respective stop lines
    draw_signal(cx - road_half_width - 20, cy - road_half_width - 5, signal_color(sig_n), "N")
    draw_signal(cx + road_half_width + 20, cy + road_half_width + 5, signal_color(sig_s), "S")
    draw_signal(cx + road_half_width + 5, cy - road_half_width - 20, signal_color(sig_e), "E")
    draw_signal(cx - road_half_width - 5, cy + road_half_width + 20, signal_color(sig_w), "W")

    # Draw Vehicles
    for v in vehicles:
        if v.completed:
            continue

        vx, vy, heading = v.get_coordinates()
        svg_x = cx + vx * scale
        svg_y = cy - vy * scale  # Invert Y so positive Y is up (North)

        # Skip if far off screen
        if svg_x < -20 or svg_x > width + 20 or svg_y < -20 or svg_y > height + 20:
            continue

        veh_len = v.length * scale
        veh_wid = 2.4 * scale

        # Color: Orange/Red if queued/waiting, vibrant Cyan/Blue if moving
        if v.is_waiting:
            car_color = "#f97316"  # Orange
            car_border = "#c2410c"
        else:
            car_color = "#38bdf8"  # Sky blue
            car_border = "#0284c7"

        # SVG transform rotation around car center
        # heading 0 = East, 90 = North (-svg_y), 180 = West, 270 = South (+svg_y)
        svg_rot = -heading

        svg.append(f'<g transform="translate({svg_x}, {svg_y}) rotate({svg_rot})">')
        # Car body
        svg.append(f'  <rect x="{-veh_len/2}" y="{-veh_wid/2}" width="{veh_len}" height="{veh_wid}" rx="3" fill="{car_color}" stroke="{car_border}" stroke-width="1.2"/>')
        # Windshield
        svg.append(f'  <rect x="{veh_len*0.05}" y="{-veh_wid*0.35}" width="{veh_len*0.2}" height="{veh_wid*0.7}" rx="1" fill="#0f172a" opacity="0.6"/>')
        # Headlights
        svg.append(f'  <circle cx="{veh_len*0.45}" cy="{-veh_wid*0.35}" r="1.5" fill="#fef08a"/>')
        svg.append(f'  <circle cx="{veh_len*0.45}" cy="{veh_wid*0.35}" r="1.5" fill="#fef08a"/>')
        svg.append('</g>')

    # HUD Overlays (Top corners)
    queues = intersection.get_queues()
    phase_text = (
        "PHASE 1: NORTH-SOUTH GREEN"
        if intersection.current_phase == SignalPhase.NS_GREEN
        else (
            "PHASE 2: EAST-WEST GREEN"
            if intersection.current_phase == SignalPhase.EW_GREEN
            else (
                "CLEARANCE: NS YELLOW"
                if intersection.current_phase == SignalPhase.NS_YELLOW
                else (
                    "CLEARANCE: EW YELLOW"
                    if intersection.current_phase == SignalPhase.EW_YELLOW
                    else "CLEARANCE: ALL RED"
                )
            )
        )
    )

    # Phase Banner
    svg.append(f'<rect x="15" y="15" width="280" height="36" rx="8" fill="#090d16" fill-opacity="0.85" stroke="#334155" stroke-width="1"/>')
    svg.append(f'<circle cx="33" cy="33" r="6" fill="{signal_color(sig_n if "NORTH-SOUTH" in phase_text else sig_e)}"/>')
    svg.append(f'<text x="48" y="37" font-family="system-ui, sans-serif" font-size="11" font-weight="600" fill="#f8fafc">{phase_text}</text>')

    # Queue summary pill
    q_str = f"Queues: N:{queues['N']}  S:{queues['S']}  E:{queues['E']}  W:{queues['W']}"
    svg.append(f'<rect x="{width - 235}" y="15" width="220" height="36" rx="8" fill="#090d16" fill-opacity="0.85" stroke="#334155" stroke-width="1"/>')
    svg.append(f'<text x="{width - 223}" y="37" font-family="monospace" font-size="11" font-weight="600" fill="#38bdf8">{q_str}</text>')

    # Time pill
    t_str = f"Sim Time: {current_time:.1f}s | In Phase: {intersection.time_in_phase:.1f}s"
    svg.append(f'<rect x="15" y="{height - 45}" width="250" height="30" rx="6" fill="#090d16" fill-opacity="0.85" stroke="#334155" stroke-width="1"/>')
    svg.append(f'<text x="25" y="{height - 25}" font-family="monospace" font-size="11" fill="#94a3b8">{t_str}</text>')

    svg.append('</svg>')
    return "\n".join(svg)
