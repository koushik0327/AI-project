"""
Plotly Interactive Charts for TrafficFlow AI.

Generates responsive, publication-quality interactive charts for:
- DRL Training rewards and moving average
- Huber loss and epsilon decay
- Fixed-Time vs DQN queue lengths over time
- Waiting time progression
- Side-by-side performance comparison bars
"""

from typing import Dict, List, Optional
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots


def create_reward_chart(rewards: List[float], window: int = 5) -> go.Figure:
    """Generate training episode rewards curve with moving average."""
    episodes = list(range(1, len(rewards) + 1))
    fig = go.Figure()

    # Raw rewards
    fig.add_trace(go.Scatter(
        x=episodes,
        y=rewards,
        mode="lines+markers",
        name="Episode Reward",
        line=dict(color="#38bdf8", width=1.5),
        marker=dict(size=4),
        opacity=0.6,
    ))

    # Moving average
    if len(rewards) >= window:
        ma = pd.Series(rewards).rolling(window=window, min_periods=1).mean()
        fig.add_trace(go.Scatter(
            x=episodes,
            y=ma,
            mode="lines",
            name=f"{window}-Ep Moving Avg",
            line=dict(color="#22c55e", width=3),
        ))

    fig.update_layout(
        title="DQN Training Reward Convergence",
        xaxis_title="Training Episode",
        yaxis_title="Cumulative Reward",
        template="plotly_dark",
        paper_bgcolor="#0f172a",
        plot_bgcolor="#1e293b",
        font=dict(color="#f8fafc"),
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


def create_loss_and_epsilon_chart(losses: List[float], epsilons: List[float]) -> go.Figure:
    """Generate dual-axis chart for training loss and epsilon decay."""
    episodes = list(range(1, len(losses) + 1))

    fig = make_subplots(specs=[[{"secondary_y": True}]])

    # Huber Loss
    fig.add_trace(
        go.Scatter(
            x=episodes,
            y=losses,
            name="Huber Loss",
            line=dict(color="#f43f5e", width=2),
        ),
        secondary_y=False,
    )

    # Epsilon Decay
    fig.add_trace(
        go.Scatter(
            x=episodes,
            y=epsilons,
            name="Exploration Epsilon",
            line=dict(color="#eab308", width=2, dash="dash"),
        ),
        secondary_y=True,
    )

    fig.update_layout(
        title="Training Loss & Epsilon Exploration Decay",
        xaxis_title="Training Episode",
        template="plotly_dark",
        paper_bgcolor="#0f172a",
        plot_bgcolor="#1e293b",
        font=dict(color="#f8fafc"),
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40),
    )
    fig.update_yaxes(title_text="Smooth L1 / Huber Loss", secondary_y=False)
    fig.update_yaxes(title_text="Epsilon Rate (ε)", secondary_y=True)
    return fig


def create_queue_comparison_chart(
    time_f: List[float],
    q_f: List[int],
    time_d: List[float],
    q_d: List[int],
) -> go.Figure:
    """Plot timeseries comparison of total intersection queue length."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=time_f,
        y=q_f,
        mode="lines",
        name="Fixed-Time Baseline",
        line=dict(color="#f97316", width=2),
    ))

    fig.add_trace(go.Scatter(
        x=time_d,
        y=q_d,
        mode="lines",
        name="Adaptive DQN Agent",
        line=dict(color="#22c55e", width=2.5),
    ))

    fig.update_layout(
        title="Intersection Queue Dynamics Over Simulation Time",
        xaxis_title="Simulation Time (seconds)",
        yaxis_title="Total Queued Vehicles",
        template="plotly_dark",
        paper_bgcolor="#0f172a",
        plot_bgcolor="#1e293b",
        font=dict(color="#f8fafc"),
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


def create_waiting_time_chart(
    time_f: List[float],
    w_f: List[float],
    time_d: List[float],
    w_d: List[float],
) -> go.Figure:
    """Plot timeseries comparison of average waiting time."""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=time_f,
        y=w_f,
        mode="lines",
        name="Fixed-Time Baseline",
        line=dict(color="#f97316", width=2),
    ))

    fig.add_trace(go.Scatter(
        x=time_d,
        y=w_d,
        mode="lines",
        name="Adaptive DQN Agent",
        line=dict(color="#38bdf8", width=2.5),
    ))

    fig.update_layout(
        title="Average Vehicle Waiting Time Progression",
        xaxis_title="Simulation Time (seconds)",
        yaxis_title="Average Waiting Time (seconds)",
        template="plotly_dark",
        paper_bgcolor="#0f172a",
        plot_bgcolor="#1e293b",
        font=dict(color="#f8fafc"),
        hovermode="x unified",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig


def create_metric_bar_chart(
    fixed_metrics: Dict[str, float],
    dqn_metrics: Dict[str, float],
) -> go.Figure:
    """Side-by-side bar chart comparing key metrics."""
    categories = [
        "Avg Wait Time (s)",
        "Avg Queue (veh)",
        "Avg Delay (s)",
        "Max Queue (veh)",
        "Throughput (veh)",
    ]

    fixed_vals = [
        fixed_metrics.get("avg_waiting_time", 0.0),
        fixed_metrics.get("avg_queue_length", 0.0),
        fixed_metrics.get("avg_vehicle_delay", 0.0),
        fixed_metrics.get("max_queue_length", 0.0),
        fixed_metrics.get("total_vehicles_processed", 0.0),
    ]

    dqn_vals = [
        dqn_metrics.get("avg_waiting_time", 0.0),
        dqn_metrics.get("avg_queue_length", 0.0),
        dqn_metrics.get("avg_vehicle_delay", 0.0),
        dqn_metrics.get("max_queue_length", 0.0),
        dqn_metrics.get("total_vehicles_processed", 0.0),
    ]

    fig = go.Figure(data=[
        go.Bar(name="Fixed-Time Baseline", x=categories, y=fixed_vals, marker_color="#f97316"),
        go.Bar(name="Adaptive DQN Agent", x=categories, y=dqn_vals, marker_color="#22c55e"),
    ])

    fig.update_layout(
        barmode="group",
        title="Performance Benchmark Comparison",
        template="plotly_dark",
        paper_bgcolor="#0f172a",
        plot_bgcolor="#1e293b",
        font=dict(color="#f8fafc"),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=60, b=40),
    )
    return fig
