"""
Adaptive DQN Controller for TrafficFlow AI.

Wraps a trained PyTorch DQNAgent to serve as an intelligent, reactive
traffic signal controller in the live simulation and evaluation loops.
"""

from typing import Any, Dict, Optional
import numpy as np

from agent.dqn_agent import DQNAgent


class AdaptiveDQNController:
    """Adaptive controller utilizing a Deep Q-Network policy."""

    def __init__(
        self,
        agent: Optional[DQNAgent] = None,
        model_path: Optional[str] = None,
    ):
        """
        Initialize the adaptive controller.

        Args:
            agent: Pre-initialized DQNAgent.
            model_path: Optional path to saved PyTorch checkpoint.
        """
        if agent is not None:
            self.agent = agent
        else:
            self.agent = DQNAgent()

        if model_path is not None:
            self.load(model_path)

    def select_action(
        self,
        state: np.ndarray,
        dt: float = 1.0,
        info: Optional[Dict[str, Any]] = None,
    ) -> int:
        """
        Select the optimal signal phase using the trained Q-network (eval mode).

        Args:
            state: 15-D normalized observation vector.
            dt: Simulation timestep.
            info: Optional environment state metadata.

        Returns:
            Action integer (0 for NS_GREEN, 1 for EW_GREEN).
        """
        return self.agent.select_action(state, eval_mode=True)

    def load(self, model_path: str) -> bool:
        """Load weights from a checkpoint file."""
        return self.agent.load(model_path)

    def reset(self) -> None:
        """Reset internal controller state."""
        pass
