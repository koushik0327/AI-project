"""
Fixed-Time Baseline Controller for TrafficFlow AI.

Implements traditional deterministic pre-timed traffic signal control
with configurable green phase durations for North-South and East-West.
"""

from typing import Any, Dict
import numpy as np


class FixedTimeController:
    """Deterministic fixed-time traffic signal controller baseline."""

    def __init__(
        self,
        ns_green_duration: float = 30.0,
        ew_green_duration: float = 30.0,
    ):
        """
        Initialize the fixed-time controller.

        Args:
            ns_green_duration: Duration of North-South green in seconds.
            ew_green_duration: Duration of East-West green in seconds.
        """
        self.ns_green_duration = ns_green_duration
        self.ew_green_duration = ew_green_duration

        # 0: NS_GREEN, 1: EW_GREEN
        self.active_phase = 0
        self.timer = 0.0

    def reset(self) -> None:
        """Reset internal timers and starting phase."""
        self.active_phase = 0
        self.timer = 0.0

    def select_action(
        self,
        state: np.ndarray,
        dt: float = 1.0,
        info: Dict[str, Any] = None,
    ) -> int:
        """
        Determine action based purely on elapsed clock time.

        Args:
            state: Current environment state vector (ignored by fixed controller).
            dt: Simulation timestep in seconds.
            info: Optional environment diagnostics.

        Returns:
            Action integer: 0 for NS_GREEN, 1 for EW_GREEN.
        """
        self.timer += dt

        target_duration = (
            self.ns_green_duration if self.active_phase == 0 else self.ew_green_duration
        )

        if self.timer >= target_duration:
            # Switch to alternative phase
            self.active_phase = 1 - self.active_phase
            self.timer = 0.0

        return self.active_phase
