"""
Traffic Environment for TrafficFlow AI.

Provides a standard reinforcement learning interface with:
- Exact 15-dimensional normalized state vector
- Safety-enforced action semantics (min green, max green, yellow/all-red clearance)
- Explicit mathematical multi-objective reward function
- Discrete queue-based dynamics with smooth moving-vehicle coordinates
- Pre-generated arrival schedule support for scientifically fair evaluation
"""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np

from environment.intersection import Intersection, SignalPhase
from environment.traffic_generator import TrafficGenerator, TrafficSchedule
from environment.vehicle import Vehicle


class TrafficEnvironment:
    """
    Simulated 4-way intersection reinforcement learning environment.

    Exact 15-Dimensional State Space:
        [0:4]   Normalized approach queue lengths: [Q_N, Q_S, Q_E, Q_W] / 30.0
        [4:8]   Normalized average waiting times: [W_N, W_S, W_E, W_W] / 60.0
        [8:12]  Normalized arrival-rate estimates: [lambda_N, lambda_S, lambda_E, lambda_W] / 0.5
        [12:14] One-hot current signal phase indicators:
                - [1.0, 0.0]: Phase 1 (NS Green, EW Red)
                - [0.0, 1.0]: Phase 2 (EW Green, NS Red)
                - [0.0, 0.0]: Transition (Yellow / All-Red clearance)
        [14]    Normalized elapsed green time: t_elapsed / 60.0

    Action Space:
        0: Request Phase 1 (NS Green)
        1: Request Phase 2 (EW Green)
    """

    STATE_DIM = 15
    ACTION_DIM = 2

    # Normalization scaling constants
    MAX_QUEUE_SCALE = 30.0
    MAX_WAIT_SCALE = 60.0
    MAX_RATE_SCALE = 0.5
    MAX_GREEN_SCALE = 60.0

    def __init__(
        self,
        traffic_preset: str = "medium",
        episode_duration: float = 300.0,
        dt: float = 1.0,
        min_green_time: float = 10.0,
        max_green_time: float = 60.0,
        yellow_time: float = 3.0,
        all_red_time: float = 1.0,
        seed: Optional[int] = 42,
        schedule: Optional[TrafficSchedule] = None,
    ):
        """
        Initialize the environment.

        Args:
            traffic_preset: Traffic density regime ('low', 'medium', 'rush_hour', 'asymmetric').
            episode_duration: Duration of episode in seconds.
            dt: Simulation timestep (1.0s).
            min_green_time: Minimum green duration before switching allowed (10s).
            max_green_time: Maximum green duration before forced switch (60s).
            yellow_time: Yellow clearance duration (3s).
            all_red_time: All-red conflict clearance duration (1s).
            seed: Reproducible seed.
            schedule: Optional pre-generated arrival schedule for fair evaluation.
        """
        self.traffic_preset = traffic_preset
        self.episode_duration = episode_duration
        self.dt = dt
        self.seed = seed

        self.intersection = Intersection(
            min_green_time=min_green_time,
            max_green_time=max_green_time,
            yellow_time=yellow_time,
            all_red_time=all_red_time,
        )
        self.traffic_generator = TrafficGenerator(
            preset=traffic_preset, seed=seed, schedule=schedule
        )

        # Simulation clock
        self.current_time = 0.0
        self.step_idx = 0

        # Arrival rate estimators (exponential moving average per approach)
        self.arrival_rate_ema = {"N": 0.15, "S": 0.15, "E": 0.15, "W": 0.15}
        self.ema_alpha = 0.08  # ~12-15s rolling adaptation

        # Episode metric tracking
        self.completed_vehicles: List[Vehicle] = []
        self.all_spawned_vehicles: List[Vehicle] = []
        self.history_time: List[float] = []
        self.history_queues: Dict[str, List[int]] = {"N": [], "S": [], "E": [], "W": []}
        self.history_total_queue: List[int] = []
        self.history_avg_wait: List[float] = []
        self.history_phases: List[int] = []
        self.history_throughput: List[int] = []

        # Explicit reward function weights
        self.w_queue = 0.04       # Penalty per queued vehicle
        self.w_wait = 0.01        # Penalty per second of average wait time
        self.w_switch = 0.40      # Penalty for phase switch request
        self.w_throughput = 0.30  # Reward per vehicle exiting intersection

    def reset(
        self,
        seed: Optional[int] = None,
        schedule: Optional[TrafficSchedule] = None,
    ) -> np.ndarray:
        """
        Reset simulation state.

        Args:
            seed: Optional seed override.
            schedule: Optional pre-generated arrival schedule override.
        """
        if seed is not None:
            self.seed = seed
        if schedule is not None:
            self.traffic_generator.set_schedule(schedule)

        self.current_time = 0.0
        self.step_idx = 0
        self.completed_vehicles.clear()
        self.all_spawned_vehicles.clear()

        self.history_time.clear()
        self.history_queues = {"N": [], "S": [], "E": [], "W": []}
        self.history_total_queue.clear()
        self.history_avg_wait.clear()
        self.history_phases.clear()
        self.history_throughput.clear()

        # Reset arrival rate EMA
        initial_rate = (
            TrafficSchedule.PRESETS.get(self.traffic_preset, {}).get("N", 0.15)
        )
        self.arrival_rate_ema = {"N": initial_rate, "S": initial_rate, "E": initial_rate, "W": initial_rate}

        self.intersection.reset()
        self.traffic_generator.reset(seed=self.seed)

        return self._get_state()

    def _get_state(self) -> np.ndarray:
        """
        Construct exact 15-dimensional normalized state vector:
        [0:4]   Normalized approach queue lengths (N, S, E, W)
        [4:8]   Normalized average waiting times (N, S, E, W)
        [8:12]  Normalized arrival-rate estimates (N, S, E, W)
        [12:14] One-hot current signal phase indicators
        [14]    Normalized elapsed green time
        """
        queues = self.intersection.get_queues()
        avg_waits = self.intersection.get_average_wait_times()

        # 1. Normalized queues [0:4]
        q_norm = [
            min(1.0, queues["N"] / self.MAX_QUEUE_SCALE),
            min(1.0, queues["S"] / self.MAX_QUEUE_SCALE),
            min(1.0, queues["E"] / self.MAX_QUEUE_SCALE),
            min(1.0, queues["W"] / self.MAX_QUEUE_SCALE),
        ]

        # 2. Normalized average wait times [4:8]
        w_norm = [
            min(1.0, avg_waits["N"] / self.MAX_WAIT_SCALE),
            min(1.0, avg_waits["S"] / self.MAX_WAIT_SCALE),
            min(1.0, avg_waits["E"] / self.MAX_WAIT_SCALE),
            min(1.0, avg_waits["W"] / self.MAX_WAIT_SCALE),
        ]

        # 3. Normalized arrival rate estimates [8:12]
        r_norm = [
            min(1.0, self.arrival_rate_ema["N"] / self.MAX_RATE_SCALE),
            min(1.0, self.arrival_rate_ema["S"] / self.MAX_RATE_SCALE),
            min(1.0, self.arrival_rate_ema["E"] / self.MAX_RATE_SCALE),
            min(1.0, self.arrival_rate_ema["W"] / self.MAX_RATE_SCALE),
        ]

        # 4. One-hot signal phase indicators [12:14]
        if self.intersection.current_phase == SignalPhase.NS_GREEN:
            phase_one_hot = [1.0, 0.0]
        elif self.intersection.current_phase == SignalPhase.EW_GREEN:
            phase_one_hot = [0.0, 1.0]
        else:
            # During Yellow or All-Red clearance transitions
            phase_one_hot = [0.0, 0.0]

        # 5. Normalized elapsed green time [14]
        time_norm = min(1.0, self.intersection.time_in_phase / self.MAX_GREEN_SCALE)

        state = np.array(
            q_norm + w_norm + r_norm + phase_one_hot + [time_norm],
            dtype=np.float32,
        )
        return state

    def step(self, action: int) -> Tuple[np.ndarray, float, bool, Dict[str, Any]]:
        """
        Advance simulation by dt seconds.

        Safety Enforcement:
        - If action requests a switch before min_green_time (10s), the request is held.
        - If elapsed green exceeds max_green_time (60s), a switch is forced.
        - All transitions safely pass through yellow clearance (3s) and all-red clearance (1s).
        - Conflicting directions are never green simultaneously.

        Args:
            action: 0 (request NS_GREEN) or 1 (request EW_GREEN).

        Returns:
            Tuple of (next_state, reward, done, info_dict).
        """
        # Process action via safety-governed intersection logic
        switch_initiated = False
        target_phase = SignalPhase.NS_GREEN if action == 0 else SignalPhase.EW_GREEN

        if self.intersection.current_phase != target_phase:
            switch_initiated = self.intersection.request_phase(target_phase)

        # Update intersection traffic signal state and clearance timers
        self.intersection.update_signals(self.dt)

        # Spawn vehicles using generator or pre-generated schedule
        new_vehicles = self.traffic_generator.step(
            self.dt, self.current_time, self.step_idx, self.intersection.vehicles
        )
        for v in new_vehicles:
            self.intersection.vehicles[v.approach].append(v)
            self.all_spawned_vehicles.append(v)

        # Update arrival rate exponential moving averages
        step_arrivals = {"N": 0, "S": 0, "E": 0, "W": 0}
        for v in new_vehicles:
            step_arrivals[v.approach] += 1
        for app in ["N", "S", "E", "W"]:
            instant_rate = step_arrivals[app] / self.dt
            self.arrival_rate_ema[app] = (
                self.ema_alpha * instant_rate + (1.0 - self.ema_alpha) * self.arrival_rate_ema[app]
            )

        # Update vehicle kinematics and discrete queue movement
        vehicles_exited_this_step = 0
        for approach in ["N", "S", "E", "W"]:
            veh_list = self.intersection.vehicles[approach]
            signal_state = self.intersection.get_signal_state(approach)

            # Sort vehicles by position (furthest ahead first)
            veh_list.sort(key=lambda v: v.position, reverse=True)

            lead_veh = None
            active_vehicles = []
            for v in veh_list:
                was_completed = v.completed

                v.update(self.dt, self.current_time, signal_state, lead_veh)

                # Throughput: count vehicles that have completed traversal and exited
                if v.completed and not was_completed:
                    vehicles_exited_this_step += 1
                    self.completed_vehicles.append(v)
                elif not v.completed:
                    active_vehicles.append(v)
                    lead_veh = v

            self.intersection.vehicles[approach] = active_vehicles

        # Advance clock
        self.current_time += self.dt
        self.step_idx += 1

        # Diagnostic state measures
        queues = self.intersection.get_queues()
        total_queue = sum(queues.values())
        avg_waits = self.intersection.get_average_wait_times()
        total_avg_wait = sum(avg_waits.values()) / 4.0

        # Mathematical Multi-Objective Reward:
        # R = - w_q * sum(Q_i) - w_w * sum(W_i) + w_t * N_exited - w_s * I(switch)
        reward = (
            - self.w_queue * total_queue
            - self.w_wait * sum(avg_waits.values())
            + self.w_throughput * vehicles_exited_this_step
            - (self.w_switch if switch_initiated else 0.0)
        )

        done = self.current_time >= self.episode_duration

        # Record histories
        self.history_time.append(self.current_time)
        for app in ["N", "S", "E", "W"]:
            self.history_queues[app].append(queues[app])
        self.history_total_queue.append(total_queue)
        self.history_avg_wait.append(total_avg_wait)
        self.history_phases.append(int(self.intersection.current_phase))
        self.history_throughput.append(len(self.completed_vehicles))

        next_state = self._get_state()
        info = {
            "time": self.current_time,
            "total_queue": total_queue,
            "queues": queues,
            "avg_wait": total_avg_wait,
            "phase": self.intersection.current_phase,
            "vehicles_completed": len(self.completed_vehicles),
            "vehicles_exited_step": vehicles_exited_this_step,
        }

        return next_state, reward, done, info

    def get_all_active_vehicles(self) -> List[Vehicle]:
        """Return a flat list of all active vehicles across all approaches."""
        active = []
        for v_list in self.intersection.vehicles.values():
            active.extend(v_list)
        return active
