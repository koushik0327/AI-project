"""
Vehicle Class for TrafficFlow AI Simulation.

Models vehicle kinematics, car-following behavior (Intelligent Driver Model),
waiting time accumulation, and 2D spatial positioning for rendering.
"""

import math
from typing import Optional, Tuple


class Vehicle:
    """Represents an individual vehicle traveling through the 4-way intersection."""

    # Intersection geometric constants (in meters)
    STOP_LINE_POS = 150.0      # Distance from spawn point to stop line
    INTERSECTION_WIDTH = 30.0   # Width of intersection conflict zone
    EXIT_POS = 240.0           # Distance at which vehicle exits simulation
    LANE_OFFSET = 4.5          # Center offset of traffic lane from road centerline

    def __init__(
        self,
        vehicle_id: int,
        approach: str,
        spawn_time: float,
        speed: float = 8.0,
        max_speed: float = 12.5,
        length: float = 4.5,
        min_gap: float = 2.5,
        max_accel: float = 2.5,
        max_decel: float = 3.5,
    ):
        """
        Initialize a vehicle.

        Args:
            vehicle_id: Unique integer identifier.
            approach: Approach direction ('N', 'S', 'E', 'W').
            spawn_time: Simulation timestamp (seconds) when vehicle spawned.
            speed: Initial speed in m/s.
            max_speed: Desired free-flow speed in m/s (~45 km/h).
            length: Vehicle physical length in meters.
            min_gap: Minimum standstill distance in meters.
            max_accel: Maximum comfortable acceleration (m/s^2).
            max_decel: Maximum comfortable deceleration (m/s^2).
        """
        self.id = vehicle_id
        self.approach = approach.upper()
        self.spawn_time = spawn_time
        self.speed = max(0.0, speed)
        self.max_speed = max_speed
        self.length = length
        self.min_gap = min_gap
        self.max_accel = max_accel
        self.max_decel = max_decel

        # Kinematic state
        self.position = 0.0  # Distance along approach path (0 to EXIT_POS)
        self.acceleration = 0.0
        self.is_waiting = False
        self.waiting_time = 0.0
        self.total_travel_time = 0.0
        self.passed_stop_line = False
        self.completed = False
        self.exit_time: Optional[float] = None

    def update(
        self,
        dt: float,
        current_time: float,
        signal_state: str,
        lead_vehicle: Optional["Vehicle"] = None,
    ) -> None:
        """
        Update vehicle position and speed using Intelligent Driver Model (IDM).

        Args:
            dt: Timestep in seconds.
            current_time: Current simulation time.
            signal_state: 'GREEN', 'YELLOW', or 'RED' for this approach.
            lead_vehicle: The vehicle directly ahead in the same lane, if any.
        """
        if self.completed:
            return

        self.total_travel_time = current_time - self.spawn_time

        # Determine effective obstacle: lead vehicle vs traffic light stop line
        target_distance = None
        target_speed = 0.0

        # Check traffic signal if vehicle hasn't crossed the stop line
        if not self.passed_stop_line:
            distance_to_stop_line = self.STOP_LINE_POS - (self.position + self.length)

            if distance_to_stop_line <= 0:
                self.passed_stop_line = True
            elif signal_state in ("RED", "YELLOW"):
                # If YELLOW and too close to stop safely, vehicle continues
                safe_stopping_dist = (self.speed ** 2) / (2.0 * self.max_decel)
                if signal_state == "RED" or distance_to_stop_line > safe_stopping_dist:
                    target_distance = distance_to_stop_line
                    target_speed = 0.0

        # Check vehicle ahead
        if lead_vehicle is not None:
            net_gap = lead_vehicle.position - lead_vehicle.length - self.position
            if net_gap > 0:
                if target_distance is None or net_gap < target_distance:
                    target_distance = net_gap
                    target_speed = lead_vehicle.speed

        # IDM Acceleration calculation
        # Free acceleration term: a_max * (1 - (v / v_max)^4)
        v_ratio = self.speed / max(self.max_speed, 0.1)
        free_accel = self.max_accel * (1.0 - (v_ratio ** 4))

        # Interaction term
        if target_distance is not None and target_distance > 0.01:
            delta_v = self.speed - target_speed
            # s* = s0 + v*T + (v * delta_v) / (2 * sqrt(a * b))
            desired_gap = (
                self.min_gap
                + self.speed * 1.0  # safe time headway T = 1.0s
                + (self.speed * delta_v) / (2.0 * math.sqrt(max(0.1, self.max_accel * self.max_decel)))
            )
            desired_gap = max(self.min_gap, desired_gap)
            interaction_term = -self.max_accel * ((desired_gap / target_distance) ** 2)
        elif target_distance is not None and target_distance <= 0.01:
            # Already at or past target obstacle
            interaction_term = -self.max_decel
        else:
            interaction_term = 0.0

        total_accel = free_accel + interaction_term
        # Clamp acceleration within physical limits
        self.acceleration = max(-self.max_decel * 1.5, min(self.max_accel, total_accel))

        # Integrate velocity and position
        new_speed = self.speed + self.acceleration * dt
        self.speed = max(0.0, min(self.max_speed, new_speed))
        self.position += self.speed * dt

        # Update waiting state (speed < 0.3 m/s and before/at intersection)
        if self.speed < 0.3 and not self.completed:
            self.waiting_time += dt
            self.is_waiting = True
        else:
            self.is_waiting = False

        # Check if crossed stop line
        if self.position >= self.STOP_LINE_POS and not self.passed_stop_line:
            self.passed_stop_line = True

        # Check if exited simulation boundary
        if self.position >= self.EXIT_POS:
            self.completed = True
            self.exit_time = current_time

    def get_coordinates(self) -> Tuple[float, float, float]:
        """
        Convert 1D approach distance to 2D (x, y) world coordinates and heading angle.
        Center of intersection is (0, 0).

        Returns:
            Tuple of (x, y, angle_degrees).
        """
        # Relative distance relative to stop line (stop line is at 150m)
        # rel_d < 0 means upstream, 0 to 30 is intersection, > 30 is downstream
        rel_d = self.position - self.STOP_LINE_POS

        if self.approach == "N":
            # Approaching from North (positive y) heading South (-y direction)
            # Before stop line: y = 15 - rel_d (i.e. if rel_d = -50, y = 65)
            x = -self.LANE_OFFSET
            y = 15.0 - rel_d
            heading = 270.0  # South
        elif self.approach == "S":
            # Approaching from South (negative y) heading North (+y direction)
            x = self.LANE_OFFSET
            y = -15.0 + rel_d
            heading = 90.0   # North
        elif self.approach == "E":
            # Approaching from East (positive x) heading West (-x direction)
            x = 15.0 - rel_d
            y = self.LANE_OFFSET
            heading = 180.0  # West
        elif self.approach == "W":
            # Approaching from West (negative x) heading East (+x direction)
            x = -15.0 + rel_d
            y = -self.LANE_OFFSET
            heading = 0.0    # East
        else:
            x, y, heading = 0.0, 0.0, 0.0

        return x, y, heading

    def get_delay(self) -> float:
        """
        Calculate total delay experienced by vehicle compared to free-flow travel.

        Returns:
            Delay in seconds.
        """
        ideal_time = self.position / max(self.max_speed, 0.1)
        return max(0.0, self.total_travel_time - ideal_time)
