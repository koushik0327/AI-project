"""
Traffic Generator and Pre-Generated Arrival Schedules for TrafficFlow AI.

Generates reproducible vehicle arrivals across North, South, East, and West approaches.
Supports both online Poisson generation and pre-generated deterministic arrival schedules
for perfectly fair scientific comparisons across controllers.
"""

from typing import Dict, List, Optional
import numpy as np
from environment.vehicle import Vehicle


class TrafficSchedule:
    """Pre-generated deterministic arrival schedule for fair evaluation."""

    PRESETS = {
        "low": {"N": 0.08, "S": 0.08, "E": 0.08, "W": 0.08},
        "medium": {"N": 0.18, "S": 0.18, "E": 0.18, "W": 0.18},
        "rush_hour": {"N": 0.35, "S": 0.35, "E": 0.35, "W": 0.35},
        "asymmetric": {"N": 0.38, "S": 0.38, "E": 0.10, "W": 0.10},
    }

    def __init__(
        self,
        duration: float = 300.0,
        dt: float = 1.0,
        preset: str = "medium",
        seed: int = 42,
    ):
        """
        Pre-compute all vehicle arrivals across all approaches for the full duration.

        Args:
            duration: Total episode duration in seconds.
            dt: Simulation timestep.
            preset: Traffic regime ('low', 'medium', 'rush_hour', 'asymmetric').
            seed: Reproducible seed.
        """
        self.duration = duration
        self.dt = dt
        self.preset = preset
        self.seed = seed
        self.rates = self.PRESETS.get(preset, self.PRESETS["medium"])

        # Pre-generate arrivals: schedule[step_idx] = {'N': count, 'S': count, 'E': count, 'W': count}
        self.schedule: List[Dict[str, int]] = []
        rng = np.random.RandomState(seed)

        num_steps = int(np.ceil(duration / dt))
        for _ in range(num_steps):
            step_arrivals = {}
            for app in ["N", "S", "E", "W"]:
                rate = self.rates[app]
                prob = 1.0 - np.exp(-rate * dt)
                # Count of arrivals in this timestep (usually 0 or 1)
                count = 1 if rng.rand() < prob else 0
                step_arrivals[app] = count
            self.schedule.append(step_arrivals)

    def get_arrivals(self, step_idx: int) -> Dict[str, int]:
        """Retrieve pre-generated arrivals for a specific simulation step."""
        if step_idx < len(self.schedule):
            return self.schedule[step_idx]
        return {"N": 0, "S": 0, "E": 0, "W": 0}


class TrafficGenerator:
    """Manages vehicle arrivals using either online stochastic RNG or a pre-generated schedule."""

    def __init__(
        self,
        preset: str = "medium",
        seed: Optional[int] = 42,
        schedule: Optional[TrafficSchedule] = None,
    ):
        self.preset = preset
        self.seed = seed
        self.schedule = schedule
        self.vehicle_counter = 0

        # Fallback online generator
        self.rates = TrafficSchedule.PRESETS.get(preset, TrafficSchedule.PRESETS["medium"]).copy()
        self.rng = np.random.RandomState(seed if seed is not None else 42)

    def set_schedule(self, schedule: TrafficSchedule) -> None:
        """Assign a pre-generated schedule for fair evaluation."""
        self.schedule = schedule
        self.preset = schedule.preset

    def reset(self, seed: Optional[int] = None) -> None:
        """Reset vehicle counter and random state."""
        if seed is not None:
            self.seed = seed
        self.rng = np.random.RandomState(self.seed if self.seed is not None else 42)
        self.vehicle_counter = 0

    def step(
        self,
        dt: float,
        current_time: float,
        step_idx: int,
        approach_vehicles: Dict[str, List[Vehicle]],
    ) -> List[Vehicle]:
        """
        Generate arrivals for the current step.

        If a pre-generated schedule is set, arrivals are taken directly from it.
        Otherwise, arrivals are generated online using Poisson probabilities.
        """
        new_vehicles = []
        min_spawn_clearance = 8.0  # meters required before spawning next vehicle

        if self.schedule is not None:
            arrival_counts = self.schedule.get_arrivals(step_idx)
        else:
            arrival_counts = {}
            for app in ["N", "S", "E", "W"]:
                rate = self.rates.get(app, 0.15)
                prob = 1.0 - np.exp(-rate * dt)
                arrival_counts[app] = 1 if self.rng.rand() < prob else 0

        for approach in ["N", "S", "E", "W"]:
            count = arrival_counts.get(approach, 0)
            if count > 0:
                existing = approach_vehicles.get(approach, [])
                can_spawn = True
                if existing:
                    min_pos = min(v.position for v in existing)
                    if min_pos < min_spawn_clearance:
                        can_spawn = False

                if can_spawn:
                    self.vehicle_counter += 1
                    veh = Vehicle(
                        vehicle_id=self.vehicle_counter,
                        approach=approach,
                        spawn_time=current_time,
                        speed=8.5,
                        max_speed=12.5,
                        length=4.5,
                        min_gap=2.5,
                    )
                    new_vehicles.append(veh)

        return new_vehicles
