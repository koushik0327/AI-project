"""
Intersection Model for TrafficFlow AI Simulation.

Manages signal light phases, transition safety (yellow clearance, minimum green,
maximum green enforcement), and vehicle state indexing across the 4 approaches.
"""

from enum import IntEnum
from typing import Dict, List, Optional
from environment.vehicle import Vehicle


class SignalPhase(IntEnum):
    """Signal phase states for the 4-way intersection."""
    NS_GREEN = 0        # North-South Green, East-West Red
    EW_GREEN = 1        # East-West Green, North-South Red
    NS_YELLOW = 2       # North-South Yellow clearance, East-West Red
    EW_YELLOW = 3       # East-West Yellow clearance, North-South Red
    ALL_RED = 4         # All approaches Red (conflict clearance)


class Intersection:
    """Represents the 4-way intersection geometry, signals, and queues."""

    def __init__(
        self,
        min_green_time: float = 10.0,
        max_green_time: float = 60.0,
        yellow_time: float = 3.0,
        all_red_time: float = 1.0,
    ):
        """
        Initialize the intersection.

        Args:
            min_green_time: Minimum mandatory green duration before switching (seconds).
            max_green_time: Maximum allowable green duration before forced switch (seconds).
            yellow_time: Yellow light clearance duration (seconds).
            all_red_time: All-red conflict clearance duration (seconds).
        """
        self.min_green_time = min_green_time
        self.max_green_time = max_green_time
        self.yellow_time = yellow_time
        self.all_red_time = all_red_time

        # Initial state
        self.current_phase = SignalPhase.NS_GREEN
        self.time_in_phase = 0.0
        self.pending_target_phase: Optional[SignalPhase] = None
        self.transition_timer = 0.0

        # Approaches storage
        self.vehicles: Dict[str, List[Vehicle]] = {
            "N": [],
            "S": [],
            "E": [],
            "W": [],
        }

    def reset(self) -> None:
        """Reset the intersection to initial phase and clear vehicles."""
        self.current_phase = SignalPhase.NS_GREEN
        self.time_in_phase = 0.0
        self.pending_target_phase = None
        self.transition_timer = 0.0
        for approach in self.vehicles:
            self.vehicles[approach] = []

    def get_signal_state(self, approach: str) -> str:
        """
        Get current signal color for a specific approach ('GREEN', 'YELLOW', 'RED').
        Conflicting directions are NEVER green simultaneously.
        """
        approach = approach.upper()
        if self.current_phase == SignalPhase.NS_GREEN:
            return "GREEN" if approach in ("N", "S") else "RED"
        elif self.current_phase == SignalPhase.EW_GREEN:
            return "GREEN" if approach in ("E", "W") else "RED"
        elif self.current_phase == SignalPhase.NS_YELLOW:
            return "YELLOW" if approach in ("N", "S") else "RED"
        elif self.current_phase == SignalPhase.EW_YELLOW:
            return "YELLOW" if approach in ("E", "W") else "RED"
        elif self.current_phase == SignalPhase.ALL_RED:
            return "RED"
        return "RED"

    def request_phase(self, target_phase: int) -> bool:
        """
        Request a primary phase (0 = NS_GREEN, 1 = EW_GREEN).

        Returns:
            True if phase transition was initiated or already in target,
            False if blocked by min green constraint or transition in progress.
        """
        target = SignalPhase(target_phase)
        if target not in (SignalPhase.NS_GREEN, SignalPhase.EW_GREEN):
            return False

        # If already in the target phase and not in transition
        if self.current_phase == target and self.pending_target_phase is None:
            return True

        # If a transition is already underway, cannot accept new switch yet
        if self.pending_target_phase is not None:
            return False

        # If min green duration has not elapsed, switch cannot happen yet
        if self.time_in_phase < self.min_green_time:
            return False

        # Initiate safe yellow transition
        self.pending_target_phase = target
        if self.current_phase == SignalPhase.NS_GREEN:
            self.current_phase = SignalPhase.NS_YELLOW
        elif self.current_phase == SignalPhase.EW_GREEN:
            self.current_phase = SignalPhase.EW_YELLOW

        self.transition_timer = 0.0
        return True

    def update_signals(self, dt: float) -> bool:
        """
        Advance signal timers and execute transitions safely.
        Enforces maximum green timeout.

        Args:
            dt: Timestep in seconds.

        Returns:
            True if a phase switch occurred in this timestep.
        """
        self.time_in_phase += dt
        phase_switched = False

        # Check for forced switch due to max green limit
        if self.pending_target_phase is None:
            if self.time_in_phase >= self.max_green_time:
                # Force switch to the alternative phase
                alt_phase = (
                    SignalPhase.EW_GREEN
                    if self.current_phase == SignalPhase.NS_GREEN
                    else SignalPhase.NS_GREEN
                )
                self.request_phase(alt_phase)

        # Handle active transitions
        if self.pending_target_phase is not None:
            self.transition_timer += dt

            # Transition from YELLOW to ALL_RED
            if self.current_phase in (SignalPhase.NS_YELLOW, SignalPhase.EW_YELLOW):
                if self.transition_timer >= self.yellow_time:
                    self.current_phase = SignalPhase.ALL_RED
                    self.transition_timer = 0.0

            # Transition from ALL_RED to final target GREEN
            elif self.current_phase == SignalPhase.ALL_RED:
                if self.transition_timer >= self.all_red_time:
                    self.current_phase = self.pending_target_phase
                    self.pending_target_phase = None
                    self.time_in_phase = 0.0
                    self.transition_timer = 0.0
                    phase_switched = True

        return phase_switched

    def get_queues(self) -> Dict[str, int]:
        """
        Count number of queued vehicles per approach.
        A vehicle is queued if it is waiting before the stop line (rel_d <= 2.0).
        """
        queues = {}
        for app, veh_list in self.vehicles.items():
            count = sum(
                1
                for v in veh_list
                if (v.is_waiting or v.speed < 0.5) and v.position < (Vehicle.STOP_LINE_POS + 2.0)
            )
            queues[app] = count
        return queues

    def get_average_wait_times(self) -> Dict[str, float]:
        """Get average waiting time in seconds of vehicles on each approach."""
        avg_waits = {}
        for app, veh_list in self.vehicles.items():
            active = [v for v in veh_list if not v.completed and v.position < Vehicle.STOP_LINE_POS]
            if active:
                avg_waits[app] = sum(v.waiting_time for v in active) / len(active)
            else:
                avg_waits[app] = 0.0
        return avg_waits

    def get_approach_vehicle_counts(self) -> Dict[str, int]:
        """Count total vehicles currently approaching (before stop line)."""
        counts = {}
        for app, veh_list in self.vehicles.items():
            counts[app] = sum(1 for v in veh_list if not v.completed and v.position < Vehicle.STOP_LINE_POS)
        return counts
