# TrafficFlow AI: Comprehensive Viva Voce Examination Guide
## 18 High-Yield Viva Questions and Model Answers for B.Tech AI Evaluation

This document provides exhaustive, technically rigorous answers to potential questions asked by university professors, project guides, and external examiners during the project viva voce examination.

---

### Q1: What is the fundamental limitation of traditional fixed-time traffic controllers that Reinforcement Learning overcomes?
**Answer:**
Traditional fixed-time controllers operate strictly open-loop. They execute predetermined timing schedules (e.g., 30s North-South green followed by 30s East-West green) designed around historical average traffic data. They are fundamentally incapable of sensing real-time conditions. Consequently, when traffic arrival is non-stationary—such as sudden rush-hour bursts, directional imbalances, or late-night sparse traffic—fixed-time controllers misallocate green time to empty approaches while opposing queues idle unnecessarily. Reinforcement Learning formulates traffic control as a closed-loop Markov Decision Process (MDP), allowing an intelligent agent to continuously observe real-time queues, approaching densities, and vehicle waiting times to dynamically extend or switch phases based on actual demand.

---

### Q2: Why did you implement Deep Q-Networks (DQN) instead of classical tabular Q-learning?
**Answer:**
Tabular Q-learning maintains a discrete lookup table $Q(s, a)$ containing an entry for every state-action pair. In our 4-way intersection, the state vector is continuous and 15-dimensional, comprising real-valued queue lengths, vehicle densities, waiting times, and phase timers. Discretizing this state space into even 10 bins per dimension would yield $10^{15}$ discrete states, causing the classic **Curse of Dimensionality**. Such a table would exceed computer memory and require trillions of simulation steps to visit each state even once. DQN replaces the lookup table with a neural network as a universal function approximator, enabling the agent to generalize from seen traffic states to unseen, novel traffic configurations.

---

### Q3: Why did you implement DQN from scratch in PyTorch rather than using Stable-Baselines3 or RLlib?
**Answer:**
Implementing DQN directly from scratch in PyTorch was an intentional academic design decision:
1. **Mathematical Transparency:** It guarantees complete visibility and control over tensor operations, the Bellman target calculation, loss formulation, and gradient backpropagation.
2. **Viva Defensibility:** External frameworks abstract away critical DRL mechanics (such as the replay buffer sampling logic, gradient clipping, and target network Polyak averaging). Building it from scratch demonstrates genuine understanding of reinforcement learning algorithms rather than merely configuring high-level API wrappers.

---

### Q4: Explain the mathematical role of the Experience Replay Buffer and why it is indispensable in DQN.
**Answer:**
In standard supervised learning, gradient descent relies on the assumption that training samples are **independent and identically distributed (i.i.d.)**. In traffic simulations, consecutive observations $(s_t, s_{t+1}, s_{t+2})$ are strongly autocorrelated (e.g., if North approach is jammed at $t$, it is almost certainly jammed at $t+1$). Training a neural network directly on consecutive online transitions leads to catastrophic forgetting, biased gradient updates, and divergence.
The Experience Replay Buffer stores up to 50,000 transitions $(s, a, r, s', d)$ in a circular memory. By drawing uniform random mini-batches $\mathcal{B} \sim \mathcal{U}(\mathcal{D})$, the temporal autocorrelation is broken, restoring the i.i.d. assumption and stabilizing stochastic gradient descent.

---

### Q5: What is the "Moving Target Problem" in Deep Q-Learning, and how does your implementation solve it?
**Answer:**
In Q-learning, the target value used in the loss function is derived from the network itself:
$$y = r + \gamma \max_{a'} Q(s', a'; \theta)$$
If the same network weights $\theta$ are used to both predict $Q(s, a; \theta)$ and compute target $y$, every weight update to improve $Q(s, a)$ concurrently alters the target $y$. This creates a destabilizing feedback loop akin to a dog chasing its own tail.
Our implementation resolves this by decoupling the networks into:
1. **Policy Network $\theta$:** Actively trained via gradient descent.
2. **Target Network $\theta^-$:** A separate network with frozen weights used exclusively to compute target values.
We softly update the target network after every gradient step via Polyak averaging:
$$\theta^- \leftarrow \tau \theta + (1 - \tau) \theta^- \quad (\tau = 0.01)$$
This provides a slowly moving, stable target for gradient optimization.

---

### Q6: Walk through the mathematical design of your reward function. Why does it contain multiple weighted terms?
**Answer:**
The reward function is formulated as:
$$R_t = - w_q \sum_{i} Q_i - w_w \sum_{i} W_i - w_s \cdot \mathbb{I}(\text{switch}) + w_t \cdot N_{\text{cleared}}$$
Each term serves a distinct, complementary engineering objective:
- **$- w_q \sum Q_i$ ($w_q = 0.04$):** Minimizes total queue length across all four approaches.
- **$- w_w \sum W_i$ ($w_w = 0.01$):** Penalizes long idle times, discouraging the agent from starving one approach while servicing another.
- **$- w_s \cdot \mathbb{I}(\text{switch})$ ($w_s = 0.40$):** Imposes a switching penalty. Without this penalty, the agent might alternate signals every few seconds to clear single vehicles, causing severe clearance loss and high-frequency flickering.
- **$+ w_t \cdot N_{\text{cleared}}$ ($w_t = 0.25$):** Directly incentivizes high vehicle throughput by providing a positive bonus for every vehicle traversing the intersection.

---

### Q7: Why did you choose Huber Loss (Smooth L1) over standard Mean Squared Error (MSE)?
**Answer:**
Traffic environments experience stochastic surges (e.g., sudden arrival of a large vehicle platoon or an abrupt clearance delay). Under Mean Squared Error ($MSE = (Q - y)^2$), large prediction errors are squared, producing massive gradient spikes that can destabilize or blow up neural network weights.
Huber loss (Smooth L1) combines the advantages of MSE and Mean Absolute Error (MAE):
$$L_\delta(e) = \begin{cases} 
0.5 e^2 & \text{if } |e| \le 1.0 \\
|e| - 0.5 & \text{otherwise}
\end{cases}$$
It is quadratic for small errors (providing smooth convergence near the minimum) and linear for large errors (capping gradient magnitudes at $\pm 1.0$), ensuring stable learning.

---

### Q8: How does your system guarantee traffic safety and prevent real-world hazards?
**Answer:**
The DQN policy does not directly actuate light bulbs; instead, its output action is passed through a deterministic **Safety Supervisory Layer** that enforces three strict invariants:
1. **Minimum Green Time ($10\text{s}$):** Even if the agent selects a phase switch, the action is blocked until the active phase has been green for at least 10 seconds.
2. **Clearance Sequence:** Phase transitions strictly execute a 3-second Yellow light followed by a 1-second All-Red conflict clearance phase to allow vehicles in the intersection box to clear before opposing lanes receive green.
3. **Mutual Exclusion:** Conflicting directions (North-South and East-West) are mathematically prevented from displaying green simultaneously.

---

### Q9: Describe the input state vector fed into your neural network.
**Answer:**
The state is a 15-dimensional vector where every component is normalized into the range $[0, 1]$:
- Features `[0:3]`: Normalized queue lengths on North, South, East, West approaches ($Q_i / 25$).
- Features `[4:7]`: Normalized average waiting times on North, South, East, West ($W_i / 60\text{s}$).
- Features `[8:11]`: Normalized total vehicle density approaching on North, South, East, West ($D_i / 25$).
- Feature `[12]`: Active primary phase indicator ($1.0$ for North-South Green, $0.0$ for East-West Green).
- Feature `[13]`: Normalized elapsed time in the current phase ($t_{\text{phase}} / 60\text{s}$).
- Feature `[14]`: Binary flag indicating whether minimum green time has elapsed and switching is permitted ($1.0$ or $0.0$).

---

### Q10: How do you prove that your comparative evaluation against the Fixed-Time controller is scientifically fair and unbiased?
**Answer:**
In simulation-based evaluations, stochastic variation in vehicle generation can easily bias results (e.g., if one controller receives fewer cars by chance, it might appear artificially superior).
To guarantee scientific validity:
1. Vehicle generation uses a pseudo-random number generator parameterized by a seed.
2. Both the Fixed-Time controller and the DQN agent were evaluated on **strictly identical random seeds** across 5 multi-minute trials.
3. Because the arrival seeds were identical, both controllers faced the exact same sequence of vehicle arrival times and approaches, isolating controller policy as the sole independent variable.

---

### Q11: What were the key numerical results obtained from your benchmark experiments?
**Answer:**
Across 5 seeded evaluation episodes ($240\text{s}$ each under medium traffic):
- **Average Waiting Time:** Decreased from **5.37 seconds to 1.96 seconds** (a **63.53% reduction**).
- **Average Queue Length:** Decreased from **3.07 vehicles to 1.16 vehicles** (a **62.23% reduction**).
- **Maximum Observed Queue:** Dropped from **13 vehicles to 7 vehicles** (a **46.15% reduction**).
- **Total Congestion Index:** Reduced from **737.0 veh-s to 278.4 veh-s** (a **62.23% reduction**).
- **Vehicle Throughput:** Increased from **114.0 vehicles to 117.8 vehicles** (a **3.33% increase**).

---

### Q12: What is the purpose of the discount factor $\gamma$, and why did you set $\gamma = 0.95$?
**Answer:**
The discount factor $\gamma \in [0, 1)$ determines the present value of future rewards. If $\gamma = 0$, the agent is purely myopic, optimizing only immediate one-second reward. In traffic control, actions have delayed consequences: switching a signal now incurs a short-term yellow clearance penalty, but enables clearing a heavy platoon arriving 10 seconds later. Setting $\gamma = 0.95$ encourages the agent to consider long-term future flow and avoid short-sighted phase flipping.

---

### Q13: How does your traffic simulator model vehicle kinematics and car-following behavior?
**Answer:**
The simulator implements the **Intelligent Driver Model (IDM)**, a continuous microscopic traffic flow model. Acceleration is calculated as a function of the vehicle's current velocity, desired free-flow speed ($12.5\text{ m/s}$), and the net clearance distance to the vehicle ahead. When the traffic signal is Red or Yellow, the stop line is modeled as a virtual stationary obstacle, causing approaching vehicles to decelerate smoothly and come to a standstill at the stop line.

---

### Q14: How does your system handle asymmetric traffic (e.g. heavy North-South rush hour and light East-West traffic)?
**Answer:**
A fixed-time controller fails in asymmetric scenarios because it inflexibly allocates equal green duration ($30\text{s}$) to both directions, forcing the heavy North-South direction to form severe queues while East-West green time is wasted on an empty road. The DQN agent observes the high density and waiting times on North-South and dynamically sustains North-South green up to the maximum allowable duration ($60\text{s}$), switching to East-West only long enough to clear its small queue before returning to North-South.

---

### Q15: What is $\epsilon$-greedy exploration and how did you decay $\epsilon$?
**Answer:**
$\epsilon$-greedy balances **exploration** (trying unfamiliar actions to discover better policies) and **exploitation** (selecting the action with highest predicted Q-value). The agent selects a random action with probability $\epsilon$ and the greedy action $\arg\max_a Q(s, a)$ with probability $1 - \epsilon$.
We initialized $\epsilon = 1.0$ (100% exploration) and decayed it multiplicatively by $\epsilon \leftarrow \max(0.05, \epsilon \times 0.97)$ after each episode, ensuring the agent settles into a stable, high-performing exploitation policy.

---

### Q16: Why did you build a self-contained simulator instead of requiring SUMO (Simulation of Urban MObility)?
**Answer:**
While SUMO is a respected traffic simulator, it requires installing external C++ binaries, setting Windows environment variables, and configuring complex XML network/route files. This makes the project fragile, difficult to install on an examiner's laptop, and prone to platform-specific configuration failures. Developing a self-contained, physics-based Python micro-simulator guarantees that the project runs out-of-the-box in seconds on any standard laptop with zero external installation friction, while maintaining full algorithmic integrity.

---

### Q17: What are the primary engineering hurdles to deploying this system at a physical urban intersection?
**Answer:**
1. **Sensory Hardware:** Real-world intersections require reliable detection hardware (computer vision cameras, radar, or inductive loops) to estimate queue lengths and vehicle counts, which can suffer from weather occlusions or sensor drift.
2. **Pedestrian & Emergency Vehicles:** Real deployments must incorporate pedestrian call buttons and emergency vehicle preemption (e.g. fire engines and ambulances).
3. **Safety Fallbacks:** Real-world traffic controllers require dual-ring safety arbiters with automatic hardware failover to pre-timed cycling if the AI compute unit suffers a hardware glitch.

---

### Q18: How can this project be extended for a Master's thesis or future research?
**Answer:**
1. **Multi-Agent Reinforcement Learning (MARL):** Scaling from an isolated intersection to a city-wide corridor where multiple DQN agents communicate via Graph Neural Networks (GNNs) to create coordinated "green waves".
2. **Continuous Action Spaces (PPO/SAC):** Using algorithms like Proximal Policy Optimization to control continuous green phase durations rather than discrete phase selection.
3. **Multi-Modal Traffic:** Integrating dedicated phases for pedestrians, cyclists, and prioritizing public transit buses.
