"""
Unit tests for Fixed-Time Baseline and Adaptive DQN Controllers.
"""

import numpy as np
import pytest

from controllers.fixed_time_controller import FixedTimeController
from controllers.adaptive_controller import AdaptiveDQNController


def test_fixed_time_controller_cycling():
    """Verify FixedTimeController toggles phases exactly when green duration expires."""
    controller = FixedTimeController(ns_green_duration=10.0, ew_green_duration=10.0)
    state = np.zeros(15, dtype=np.float32)

    # Initial phase should be 0 (NS)
    assert controller.active_phase == 0

    # Advance 9 seconds
    for _ in range(9):
        action = controller.select_action(state, dt=1.0)
        assert action == 0

    # At 10 seconds, it should switch to 1 (EW)
    action = controller.select_action(state, dt=1.0)
    assert action == 1

    # Advance another 9 seconds under EW
    for _ in range(9):
        action = controller.select_action(state, dt=1.0)
        assert action == 1

    # At next 10 seconds, it should switch back to 0 (NS)
    action = controller.select_action(state, dt=1.0)
    assert action == 0


def test_adaptive_controller_action_selection():
    """Verify AdaptiveDQNController produces valid actions."""
    controller = AdaptiveDQNController()
    state = np.random.rand(15).astype(np.float32)

    action = controller.select_action(state, dt=1.0)
    assert action in (0, 1)
