"""
Unit tests for Traffic Environment, Intersection, Vehicle kinematics, and exact 15-D state.
"""

import pytest
import numpy as np

from environment.intersection import Intersection, SignalPhase
from environment.traffic_environment import TrafficEnvironment
from environment.traffic_generator import TrafficSchedule
from environment.vehicle import Vehicle


def test_vehicle_creation_and_movement():
    """Verify vehicle kinematics and update under green light."""
    v = Vehicle(vehicle_id=1, approach="N", spawn_time=0.0, speed=10.0, max_speed=12.0)
    assert v.position == 0.0
    assert not v.passed_stop_line
    assert not v.completed

    # Advance 5 seconds under GREEN
    for _ in range(5):
        v.update(dt=1.0, current_time=v.total_travel_time + 1.0, signal_state="GREEN", lead_vehicle=None)

    assert v.position > 40.0
    assert v.speed > 0.0
    assert not v.is_waiting


def test_vehicle_stops_at_red_light():
    """Verify that a vehicle decelerates and stops at the stop line when signal is RED."""
    v = Vehicle(vehicle_id=2, approach="N", spawn_time=0.0, speed=10.0, max_speed=12.0)
    v.position = 120.0  # Stop line is at 150.0m

    # Advance 15 seconds under RED
    for t in range(1, 16):
        v.update(dt=1.0, current_time=float(t), signal_state="RED", lead_vehicle=None)

    assert v.position <= Vehicle.STOP_LINE_POS + 1.0
    assert v.speed < 0.5
    assert v.is_waiting
    assert v.waiting_time > 0.0


def test_conflicting_directions_never_green_simultaneously():
    """Verify that North-South and East-West are never GREEN at the same time."""
    intersection = Intersection(min_green_time=5.0, yellow_time=2.0, all_red_time=1.0)

    for phase in [
        SignalPhase.NS_GREEN,
        SignalPhase.EW_GREEN,
        SignalPhase.NS_YELLOW,
        SignalPhase.EW_YELLOW,
        SignalPhase.ALL_RED,
    ]:
        intersection.current_phase = phase
        sig_n = intersection.get_signal_state("N")
        sig_s = intersection.get_signal_state("S")
        sig_e = intersection.get_signal_state("E")
        sig_w = intersection.get_signal_state("W")

        assert sig_n == sig_s
        assert sig_e == sig_w

        # Both pairs CANNOT be GREEN together
        assert not (sig_n == "GREEN" and sig_e == "GREEN")
        assert not (sig_n == "YELLOW" and sig_e == "YELLOW")


def test_minimum_green_time_constraint():
    """Verify that phase switch is rejected before minimum green time elapses."""
    intersection = Intersection(min_green_time=10.0)
    assert intersection.current_phase == SignalPhase.NS_GREEN

    # At t = 2s (< min_green_time), request switch to EW_GREEN
    intersection.time_in_phase = 2.0
    accepted = intersection.request_phase(1)  # 1 = EW_GREEN
    assert not accepted
    assert intersection.pending_target_phase is None

    # At t = 10s (>= min_green_time), request switch
    intersection.time_in_phase = 10.0
    accepted = intersection.request_phase(1)
    assert accepted
    assert intersection.current_phase == SignalPhase.NS_YELLOW
    assert intersection.pending_target_phase == SignalPhase.EW_GREEN


def test_exact_15_dimensional_state_vector():
    """Verify exact 15-dimensional state representation and normalization."""
    env = TrafficEnvironment(episode_duration=20.0, dt=1.0, seed=42)
    state = env.reset(seed=42)

    assert isinstance(state, np.ndarray)
    assert state.shape == (15,), f"Expected shape (15,), got {state.shape}"
    # Verify bounds [0, 1]
    assert np.all(state >= 0.0) and np.all(state <= 1.0)

    # State component checks
    # [12:14] is one-hot phase: initial state is NS_GREEN -> [1.0, 0.0]
    assert state[12] == 1.0 and state[13] == 0.0
    # [14] is elapsed green time: initially 0.0
    assert state[14] == 0.0

    # Step through entire episode
    total_steps = 0
    done = False
    while not done:
        action = 0  # Sustain NS Green
        next_state, reward, done, info = env.step(action)
        assert next_state.shape == (15,)
        assert isinstance(reward, float)
        assert "queues" in info
        total_steps += 1

    assert done
    assert total_steps == 20


def test_pre_generated_traffic_schedule_fairness():
    """Verify that pre-generated schedules produce identical arrivals across environments."""
    sched = TrafficSchedule(duration=30.0, dt=1.0, preset="medium", seed=999)

    env1 = TrafficEnvironment(episode_duration=30.0, dt=1.0, schedule=sched)
    env2 = TrafficEnvironment(episode_duration=30.0, dt=1.0, schedule=sched)

    env1.reset(schedule=sched)
    env2.reset(schedule=sched)

    for _ in range(30):
        _, _, _, info1 = env1.step(action=0)
        _, _, _, info2 = env2.step(action=0)
        assert info1["queues"] == info2["queues"]

    assert len(env1.all_spawned_vehicles) == len(env2.all_spawned_vehicles)
