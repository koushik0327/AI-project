"""
Unit tests for PyTorch DQN Agent, Replay Buffer, and weight updates.
"""

import os
import tempfile
import numpy as np
import pytest
import torch

from agent.dqn_agent import DQNAgent
from agent.neural_network import DQNNetwork
from agent.replay_buffer import ReplayBuffer


def test_neural_network_shapes():
    """Verify DQNNetwork input/output tensor shapes."""
    net = DQNNetwork(state_dim=15, action_dim=2, hidden_dim=64)

    # Single state
    s = torch.randn(1, 15)
    q = net(s)
    assert q.shape == (1, 2)

    # Batch of states
    batch_s = torch.randn(32, 15)
    batch_q = net(batch_s)
    assert batch_q.shape == (32, 2)


def test_replay_buffer_push_and_sample():
    """Verify replay buffer storing transitions and returning tensor batches."""
    buffer = ReplayBuffer(capacity=100)
    assert len(buffer) == 0

    # Push 10 transitions
    for i in range(10):
        s = np.zeros(15, dtype=np.float32)
        ns = np.ones(15, dtype=np.float32)
        buffer.push(s, action=i % 2, reward=float(i), next_state=ns, done=False)

    assert len(buffer) == 10

    # Sample batch of 4
    states, actions, rewards, next_states, dones = buffer.sample(batch_size=4)
    assert states.shape == (4, 15)
    assert actions.shape == (4, 1)
    assert rewards.shape == (4, 1)
    assert next_states.shape == (4, 15)
    assert dones.shape == (4, 1)


def test_agent_network_weights_actually_update():
    """
    CRITICAL TEST: Ensure agent's neural network weights change after backprop.
    Guarantees genuine PyTorch gradient updates.
    """
    agent = DQNAgent(state_dim=15, action_dim=2, batch_size=16)

    # Copy initial parameter values of the first layer
    initial_weights = [p.clone().detach() for p in agent.policy_net.parameters()]

    # Populate buffer with mock transitions
    for i in range(32):
        s = np.random.rand(15).astype(np.float32)
        ns = np.random.rand(15).astype(np.float32)
        agent.memory.push(s, action=i % 2, reward=float(i - 16), next_state=ns, done=False)

    # Execute gradient learning step
    loss = agent.learn()
    assert isinstance(loss, float)
    assert loss >= 0.0

    # Verify that at least one weight tensor has numerically changed
    updated = False
    for p_init, p_new in zip(initial_weights, agent.policy_net.parameters()):
        if not torch.allclose(p_init, p_new):
            updated = True
            break

    assert updated, "Policy network parameters failed to update after backpropagation!"


def test_epsilon_decay():
    """Verify epsilon decay reduces exploration rate down to epsilon_min."""
    agent = DQNAgent(epsilon_start=1.0, epsilon_end=0.05, epsilon_decay=0.9)
    assert agent.epsilon == 1.0

    eps1 = agent.decay_epsilon()
    assert abs(eps1 - 0.9) < 1e-4

    # Decay many times
    for _ in range(100):
        agent.decay_epsilon()

    assert agent.epsilon == 0.05


def test_agent_save_and_load():
    """Verify model checkpoint persistence and loading."""
    agent1 = DQNAgent(state_dim=15, action_dim=2)
    # Give agent1 custom epsilon
    agent1.epsilon = 0.42

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test_checkpoint.pt")
        agent1.save(path)
        assert os.path.exists(path)

        # Create fresh agent and load
        agent2 = DQNAgent(state_dim=15, action_dim=2)
        success = agent2.load(path)
        assert success
        assert abs(agent2.epsilon - 0.42) < 1e-5

        # Check that network parameters match exactly
        for p1, p2 in zip(agent1.policy_net.parameters(), agent2.policy_net.parameters()):
            assert torch.allclose(p1, p2)
