"""
Unit tests for evaluation metrics and seed reproducibility.
"""

import pytest
import numpy as np

from environment.traffic_environment import TrafficEnvironment
from evaluation.metrics import compute_metrics_from_environment
from controllers.fixed_time_controller import FixedTimeController


def test_metrics_calculation_consistency():
    """Verify that all metrics are computed with sensible numerical bounds."""
    env = TrafficEnvironment(episode_duration=30.0, dt=1.0, seed=123)
    env.reset(seed=123)

    for _ in range(30):
        env.step(action=0)

    metrics = compute_metrics_from_environment(env)
    m_dict = metrics.to_dict()

    assert "Average Waiting Time (s)" in m_dict
    assert "Average Queue Length (veh)" in m_dict
    assert "Vehicles Processed (throughput)" in m_dict
    assert "Average Delay (s)" in m_dict
    assert "Maximum Queue Length (veh)" in m_dict
    assert "Total Congestion Index (veh-s)" in m_dict

    assert metrics.avg_waiting_time >= 0.0
    assert metrics.avg_queue_length >= 0.0
    assert metrics.total_vehicles_processed >= 0
    assert metrics.max_queue_length >= 0
    assert metrics.total_congestion_index >= 0.0


def test_identical_random_seeds_produce_identical_traffic():
    """
    CRITICAL TEST: Ensure experiments are fair by proving identical seeds
    produce identical vehicle spawn patterns.
    """
    env1 = TrafficEnvironment(episode_duration=25.0, dt=1.0, seed=777)
    env2 = TrafficEnvironment(episode_duration=25.0, dt=1.0, seed=777)

    env1.reset(seed=777)
    env2.reset(seed=777)

    ctrl1 = FixedTimeController(ns_green_duration=10.0, ew_green_duration=10.0)
    ctrl2 = FixedTimeController(ns_green_duration=10.0, ew_green_duration=10.0)

    for _ in range(25):
        s1 = env1._get_state()
        s2 = env2._get_state()
        assert np.allclose(s1, s2), "States diverged on identical seed!"

        a1 = ctrl1.select_action(s1)
        a2 = ctrl2.select_action(s2)
        assert a1 == a2

        env1.step(a1)
        env2.step(a2)

    # Compare total vehicles spawned
    assert env1.traffic_generator.vehicle_counter == env2.traffic_generator.vehicle_counter
