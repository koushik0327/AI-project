"""
Performance Metrics for TrafficFlow AI Evaluation.

Precisely defined traffic engineering indicators:
1. Average vehicle waiting time (seconds) - averaged consistently over all vehicles spawned.
2. Average queue length (vehicles) - averaged across all simulation timesteps.
3. Total vehicles processed / throughput - vehicles that have actually exited the intersection.
4. Average vehicle delay (seconds) - total travel time minus ideal free-flow travel time.
5. Maximum queue length (vehicles) - peak total queue observed across any timestep.
6. Total congestion index (vehicle-seconds) - integral of total queue over simulation duration.
"""

from dataclasses import dataclass
from typing import Dict, List
import numpy as np

from environment.traffic_environment import TrafficEnvironment
from environment.vehicle import Vehicle


@dataclass
class SimulationMetrics:
    """Stores precisely computed performance metrics for an evaluation run."""
    avg_waiting_time: float
    avg_queue_length: float
    total_vehicles_processed: int
    avg_vehicle_delay: float
    max_queue_length: int
    total_congestion_index: float

    def to_dict(self) -> Dict[str, float]:
        """Convert metrics to dictionary with rounded values."""
        return {
            "Average Waiting Time (s)": round(self.avg_waiting_time, 2),
            "Average Queue Length (veh)": round(self.avg_queue_length, 2),
            "Vehicles Processed (throughput)": int(self.total_vehicles_processed),
            "Average Delay (s)": round(self.avg_vehicle_delay, 2),
            "Maximum Queue Length (veh)": int(self.max_queue_length),
            "Total Congestion Index (veh-s)": round(self.total_congestion_index, 1),
        }


def compute_metrics_from_environment(env: TrafficEnvironment) -> SimulationMetrics:
    """
    Extract and compute authentic simulation metrics from a completed environment episode.

    Args:
        env: The finished TrafficEnvironment instance.

    Returns:
        SimulationMetrics object.
    """
    # All vehicles ever spawned in this episode
    all_vehicles = list(env.all_spawned_vehicles)
    if not all_vehicles:
        # Fallback if list empty
        all_vehicles.extend(env.completed_vehicles)
        all_vehicles.extend(env.get_all_active_vehicles())

    # 1. Average waiting time across all vehicles
    if all_vehicles:
        avg_wait = float(np.mean([v.waiting_time for v in all_vehicles]))
    else:
        avg_wait = 0.0

    # 2. Average queue length averaged across all simulation timesteps
    if env.history_total_queue:
        avg_queue = float(np.mean(env.history_total_queue))
        max_queue = int(np.max(env.history_total_queue))
    else:
        avg_queue = 0.0
        max_queue = 0

    # 3. Throughput: vehicles that have actually exited the intersection
    throughput = len(env.completed_vehicles)

    # 4. Average vehicle delay (actual travel time vs ideal free-flow time)
    if all_vehicles:
        avg_delay = float(np.mean([v.get_delay() for v in all_vehicles]))
    else:
        avg_delay = 0.0

    # 6. Total congestion index (integral of total queue over time in veh-s)
    congestion_index = float(np.sum(env.history_total_queue) * env.dt)

    return SimulationMetrics(
        avg_waiting_time=avg_wait,
        avg_queue_length=avg_queue,
        total_vehicles_processed=throughput,
        avg_vehicle_delay=avg_delay,
        max_queue_length=max_queue,
        total_congestion_index=congestion_index,
    )
