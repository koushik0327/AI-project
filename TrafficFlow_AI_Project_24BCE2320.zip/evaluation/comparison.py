"""
Comparison and Benchmarking Tools for TrafficFlow AI.

Computes percentage improvements, generates structured comparison dataframes,
and manages persistence of real experimental results.
"""

from typing import Any, Dict
import pandas as pd


def generate_comparison_table(
    fixed_metrics: Dict[str, float],
    dqn_metrics: Dict[str, float],
) -> pd.DataFrame:
    """
    Construct a comparative DataFrame between Fixed-Time and DQN controllers.

    Args:
        fixed_metrics: Dictionary of baseline metrics.
        dqn_metrics: Dictionary of DQN agent metrics.

    Returns:
        Formatted pandas DataFrame with % improvements.
    """
    metric_configs = [
        ("Average Waiting Time (s)", "avg_waiting_time", "lower_better"),
        ("Average Queue Length (veh)", "avg_queue_length", "lower_better"),
        ("Vehicles Processed (throughput)", "total_vehicles_processed", "higher_better"),
        ("Average Delay (s)", "avg_vehicle_delay", "lower_better"),
        ("Maximum Queue Length (veh)", "max_queue_length", "lower_better"),
        ("Total Congestion Index (veh-s)", "total_congestion_index", "lower_better"),
    ]

    records = []
    for label, key, direction in metric_configs:
        f_val = fixed_metrics.get(key, 0.0)
        d_val = dqn_metrics.get(key, 0.0)

        diff = d_val - f_val

        # Percentage improvement calculation
        if f_val != 0:
            if direction == "lower_better":
                # For metrics where lower is better, reduction is positive improvement
                pct_imp = ((f_val - d_val) / f_val) * 100.0
            else:
                # For throughput, increase is positive improvement
                pct_imp = ((d_val - f_val) / f_val) * 100.0
        else:
            pct_imp = 0.0

        if pct_imp > 1.0:
            status = "Significant AI Advantage"
        elif pct_imp < -1.0:
            status = "Fixed-Time Advantage"
        else:
            status = "Comparable"

        records.append({
            "Metric": label,
            "Fixed-Time": round(f_val, 2),
            "DQN Agent": round(d_val, 2),
            "Difference": round(diff, 2),
            "% Improvement": round(pct_imp, 2),
            "Status": status,
        })

    return pd.DataFrame(records)
