"""
Evaluator for TrafficFlow AI Controllers.

Runs evaluation episodes using pre-generated arrival schedules to guarantee
that Fixed-Time and DQN controllers face the exact same vehicle streams.
Supports multi-regime evaluation across independent test seeds with epsilon=0.
"""

from typing import Any, Dict, List, Optional, Tuple
import numpy as np

from environment.traffic_environment import TrafficEnvironment
from environment.traffic_generator import TrafficSchedule
from evaluation.metrics import SimulationMetrics, compute_metrics_from_environment


class Evaluator:
    """Evaluates and compares traffic signal controllers on identical pre-generated schedules."""

    def __init__(self, episode_duration: float = 240.0, dt: float = 1.0):
        """
        Initialize evaluator.

        Args:
            episode_duration: Duration of each evaluation episode in seconds.
            dt: Simulation timestep (1.0s).
        """
        self.episode_duration = episode_duration
        self.dt = dt

    def run_single_episode_with_schedule(
        self,
        controller: Any,
        schedule: TrafficSchedule,
    ) -> Tuple[SimulationMetrics, Dict[str, Any]]:
        """
        Run a single evaluation episode for a controller using a fixed pre-generated schedule.

        Args:
            controller: Controller instance (FixedTimeController or AdaptiveDQNController).
            schedule: Pre-generated TrafficSchedule instance.

        Returns:
            Tuple of (SimulationMetrics, timeseries_dict).
        """
        env = TrafficEnvironment(
            traffic_preset=schedule.preset,
            episode_duration=self.episode_duration,
            dt=self.dt,
            seed=schedule.seed,
            schedule=schedule,
        )

        state = env.reset(seed=schedule.seed, schedule=schedule)
        if hasattr(controller, "reset"):
            controller.reset()

        done = False
        step_info = None

        while not done:
            # Note: For AdaptiveDQNController, select_action enforces eval_mode=True (epsilon = 0)
            action = controller.select_action(state, dt=self.dt, info=step_info)
            next_state, reward, done, step_info = env.step(action)
            state = next_state

        metrics = compute_metrics_from_environment(env)
        timeseries = {
            "time": list(env.history_time),
            "total_queue": list(env.history_total_queue),
            "queues_N": list(env.history_queues["N"]),
            "queues_S": list(env.history_queues["S"]),
            "queues_E": list(env.history_queues["E"]),
            "queues_W": list(env.history_queues["W"]),
            "avg_wait": list(env.history_avg_wait),
            "phases": list(env.history_phases),
            "throughput": list(env.history_throughput),
        }

        return metrics, timeseries

    def compare_controllers(
        self,
        fixed_controller: Any,
        dqn_controller: Any,
        num_episodes: int = 5,
        traffic_preset: str = "medium",
        test_seeds: Optional[List[int]] = None,
    ) -> Dict[str, Any]:
        """
        Run multiple seeded episodes comparing Fixed-Time vs DQN on identical pre-generated schedules.

        Args:
            fixed_controller: Baseline fixed-time controller.
            dqn_controller: AI adaptive DQN controller (eval_mode=True).
            num_episodes: Number of trial episodes.
            traffic_preset: Traffic density regime.
            test_seeds: Distinct evaluation seeds disjoint from training seeds.

        Returns:
            Dictionary with aggregated metrics and sample timeseries.
        """
        if test_seeds is None:
            # Independent test seeds disjoint from training seeds (10-50)
            test_seeds = [1001 + i * 17 for i in range(num_episodes)]
        else:
            test_seeds = test_seeds[:num_episodes]

        fixed_results: List[SimulationMetrics] = []
        dqn_results: List[SimulationMetrics] = []

        last_fixed_ts = None
        last_dqn_ts = None

        for seed in test_seeds:
            # Pre-generate arrival schedule for this seed
            schedule = TrafficSchedule(
                duration=self.episode_duration,
                dt=self.dt,
                preset=traffic_preset,
                seed=seed,
            )

            # Evaluate Fixed-Time on the exact schedule
            f_metric, f_ts = self.run_single_episode_with_schedule(fixed_controller, schedule)
            fixed_results.append(f_metric)
            last_fixed_ts = f_ts

            # Evaluate DQN on the EXACT same pre-generated schedule
            d_metric, d_ts = self.run_single_episode_with_schedule(dqn_controller, schedule)
            dqn_results.append(d_metric)
            last_dqn_ts = d_ts

        def aggregate_metrics(metrics_list: List[SimulationMetrics]) -> Dict[str, float]:
            return {
                "avg_waiting_time": float(np.mean([m.avg_waiting_time for m in metrics_list])),
                "avg_queue_length": float(np.mean([m.avg_queue_length for m in metrics_list])),
                "total_vehicles_processed": float(np.mean([m.total_vehicles_processed for m in metrics_list])),
                "avg_vehicle_delay": float(np.mean([m.avg_vehicle_delay for m in metrics_list])),
                "max_queue_length": float(np.max([m.max_queue_length for m in metrics_list])),
                "total_congestion_index": float(np.mean([m.total_congestion_index for m in metrics_list])),
            }

        avg_fixed = aggregate_metrics(fixed_results)
        avg_dqn = aggregate_metrics(dqn_results)

        return {
            "num_episodes": len(test_seeds),
            "traffic_preset": traffic_preset,
            "test_seeds": test_seeds,
            "fixed_metrics": avg_fixed,
            "dqn_metrics": avg_dqn,
            "sample_fixed_ts": last_fixed_ts,
            "sample_dqn_ts": last_dqn_ts,
        }

    def evaluate_all_regimes(
        self,
        fixed_controller: Any,
        dqn_controller: Any,
        regimes: Optional[List[str]] = None,
        test_seeds: Optional[List[int]] = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Evaluate both controllers across Low, Medium, Rush-Hour, and Asymmetric regimes.
        """
        if regimes is None:
            regimes = ["low", "medium", "rush_hour", "asymmetric"]
        if test_seeds is None:
            test_seeds = [1001, 1002, 1003]

        all_results = {}
        for regime in regimes:
            res = self.compare_controllers(
                fixed_controller,
                dqn_controller,
                num_episodes=len(test_seeds),
                traffic_preset=regime,
                test_seeds=test_seeds,
            )
            all_results[regime] = res

        return all_results
